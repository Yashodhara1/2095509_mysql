package com.web.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.Repository.StudentsRepository;
import com.web.model.Students;

@Service
public class StudentsDaoImpl implements studentsDao{

	@Autowired
	StudentsRepository studentRep;
	
	@Override
	public void insertStudent(Students students) {
		// TODO Auto-generated method stub
		studentRep.save(students);
	}

	@Override
	public void updateStudent(Students students) {
		// TODO Auto-generated method stub
		studentRep.save(students);
	}

	@Override
	public void deleteStudent(int id) {
		// TODO Auto-generated method stub
		studentRep.deleteById(id);
	}

	@Override
	public List<Students> getAllStudents() {
		// TODO Auto-generated method stub
		List<Students> stuList = studentRep.findAll();
		return stuList;
	}

	@Override
	public Students getStudentbyId(int id) {
		// TODO Auto-generated method stub
		Students students = studentRep.getById(id);
		return students;
	}

	@Override
	public Students validateStudent(Students students) {
		// TODO Auto-generated method stub
		Students student1 = studentRep.findByLoginData(students.getUserName(), students.getUserPassword());
		return student1;
	}

}
