package com.web.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.web.model.Students;



@Repository
public interface StudentsRepository extends JpaRepository<Students, Integer>{
	
	@Query("select s from Students s where s.userName=(:userName) and s.userPassword=(:userPassword)")
	Students findByLoginData(String userName, String userPassword);
}
