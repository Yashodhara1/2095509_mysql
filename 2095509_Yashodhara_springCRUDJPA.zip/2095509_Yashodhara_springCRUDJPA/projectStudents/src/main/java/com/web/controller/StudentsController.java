package com.web.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.web.model.Students;
import com.web.Dao.studentsDao;

@Controller
public class StudentsController {

	@Autowired
	Students students;

	@Autowired
	studentsDao studentsDao;

	String msg;
	
	@RequestMapping("/")
	public String index() {
		return "home";
	}
	@RequestMapping("Home")
	public String home(Model model)
	{
		model.addAttribute("students", students);
		model.addAttribute("msg", msg);
		return "index";
	}

	@RequestMapping("validate")
	public String validateStudent(@ModelAttribute("students") Students students, Model mv , HttpSession session ) {

		Students student1 = studentsDao.validateStudent(students);
		if(student1!=null) {
			msg = "Login Successful";
			session.setAttribute("students", students.getUserName());
			System.out.println("Login Successful");
			return "redirect:/show";
		}
		else {
			System.out.println("Login Failed");
			msg = "Login Failed";
			return "redirect:/";
		}

	}

	@RequestMapping("register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("students", students);
		return "register";
	}

	@RequestMapping("submitform")
	public ModelAndView saveStudent(@ModelAttribute("students") Students students, ModelAndView mv, @RequestParam("pic") MultipartFile file) throws IOException {

		System.out.println("In Save Student");
		byte[] stuPic = file.getBytes();
		students.setStuPic(stuPic);
		studentsDao.insertStudent(students);
		mv.addObject("msg", "Student Added Successfully");
		mv.setViewName("afterRegister");
		return mv;
	}
	
	@RequestMapping("getall")
	public ModelAndView getAllStudents(ModelAndView mv) {
		List<Students> stuList = studentsDao.getAllStudents();
		System.out.println(stuList);
		mv.addObject("students", stuList);
		mv.addObject("msg", msg);
		mv.setViewName("viewStudents");
		return mv;
	}
	
	@RequestMapping("getStudentform")
	public String getStudentsForm() {
		return "getStudent";
	}
	
	@RequestMapping("getbyid")
	public ModelAndView getById(@RequestParam("id") int id, ModelAndView mv) {
		Students students = studentsDao.getStudentbyId(id);
		mv.addObject("students", students);
		mv.setViewName("showStudent");
		return mv;
	}
	
	@RequestMapping("updateStudents/{id}")
	public String getUpdateStudent(@PathVariable int id, Model m) {
		
		Students students = studentsDao.getStudentbyId(id);
		System.out.println("In Controller : "+students);
		m.addAttribute("students", students);
		return "updateform";
		
	}
	
	@RequestMapping("saveUpdate")
	public String saveUpdate(@ModelAttribute("students") Students students) {
		System.out.println("in edit");
		studentsDao.updateStudent(students);
		return "redirect:/show";
	}
	
	@RequestMapping("deleteStudents/{id}")
	public String deleteStudent(@PathVariable int id) {
		System.out.println("in delete student");
		studentsDao.deleteStudent(id);
		return "redirect:/show";
	}
	
	@RequestMapping("show")
	public String Show() {
		return "afterLogin";
	}
}
