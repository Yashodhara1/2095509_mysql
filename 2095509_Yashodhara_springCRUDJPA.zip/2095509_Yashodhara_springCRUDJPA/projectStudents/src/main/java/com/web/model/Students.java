package com.web.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "students")
@Component
public class Students {
	
	@Id
	public Integer id;
	public String userName;
	public String userPassword;
	public String stuName;
	public String stuAge;
	public String stuGender;
	public String stuSubject;
	public String stuSemester;
	public Date studob;
	@Lob
	public byte[] stuPic;
	public Students() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Students(Integer id, String userName, String userPassword, String stuName, String stuAge,
			String stuGender, String stuSubject, String stuSemester, Date studob) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.stuName = stuName;
		this.stuAge = stuAge;
		this.stuGender = stuGender;
		this.stuSubject = stuSubject;
		this.stuSemester = stuSemester;
		this.studob = studob;
	}

	public Students(Integer id, String userName, String userPassword, String stuName, String stuAge,
			String stuGender, String stuSubject, String stuSemester, Date studob, byte[] stuPic) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.stuName = stuName;
		this.stuAge = stuAge;
		this.stuGender = stuGender;
		this.stuSubject = stuSubject;
		this.stuSemester = stuSemester;
		this.studob = studob;
		this.stuPic = stuPic;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public String getStuAge() {
		return stuAge;
	}
	public void setStuAge(String stuAge) {
		this.stuAge = stuAge;
	}
	public String getStuGender() {
		return stuGender;
	}
	public void setStuGender(String stuGender) {
		this.stuGender = stuGender;
	}
	public String getStuSubject() {
		return stuSubject;
	}
	public void setStuSubject(String stuSubject) {
		this.stuSubject = stuSubject;
	}
	public String getStuSemester() {
		return stuSemester;
	}
	public void setStuSemester(String stuSemester) {
		this.stuSemester = stuSemester;
	}
	public Date getStudob() {
		return studob;
	}
	public void setStudob(Date studob) {
		this.studob = studob;
	}
	public byte[] getStuPic() {
		return stuPic;
	}
	public void setStuPic(byte[] stuPic) {
		this.stuPic = stuPic;
	}
	public String getUserPicture() {
		return Base64.encodeBase64String(stuPic);
	}
	@Override
	public String toString() {
		return "Students [id=" + id + ", stuName=" + stuName + ", stuAge=" + stuAge + ", stuSubject=" + stuSubject + ", stuSemester=" + stuSemester + ", studob=" + studob + "]";
	}
	
}
