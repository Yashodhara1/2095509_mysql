package com.web.Dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.web.model.Students;

@Service
public interface studentsDao {

	public void insertStudent(Students students);
	public void updateStudent(Students students);
	public void deleteStudent(int id);
	public List<Students> getAllStudents();
	public Students getStudentbyId(int id);
	public Students validateStudent(Students students);
}
