create database rio_3_1;
use rio_3_1;

-- EXERCISE 3.1

create table trainer_info ( 
trainer_id varchar(20) primary key not null check(trainer_id like 'F%'), 
salutation varchar(7) not null, 
trainer_name varchar(30) not null, 
trainer_location varchar(30) not null, 
trainer_track varchar(15) not null, 
trainer_qualification varchar(100) not null, 
trainer_experience int null, 
trainer_email varchar(100) not null, 
trainer_password varchar(20) not null);

create table batch_info ( 
batch_id varchar(20) primary key check(batch_id like 'B%'), 
batch_owner varchar(30) not null, 
batch_bu_name varchar(30) not null);

create table module_info (
module_id varchar(20) primary key, 
module_name varchar(40) not null, 
module_duration int not null);

create table associate_info (
associate_id varchar(20) primary key not null check(associate_id like 'A%'), 
salutation varchar(7) not null, associate_name varchar(30) not null, associate_location varchar(30) not null, associate_track varchar(15) not null, associate_qualification varchar(200) not null, associate_email varchar(100) not null, associate_password varchar(20) not null);

create table questions (question_id varchar(20) primary key not null check(question_id like 'Q%'), 
module_id varchar(20) null, question_text varchar(900) not null, 
constraint fk_module_id foreign key (module_id) references module_info(module_id));

create table associate_status (associate_id varchar(20) not null, module_id varchar(20) not null, batch_id varchar(20) not null, trainer_id varchar(20) not null,start_date date null, end_date date null, 
Afeedbackgiven varchar(20) null, Tfeedbackgiven varchar(20) null,
constraint fk_associate_id foreign key(associate_id) references associate_info(associate_id),
constraint fk1_module_id foreign key(module_id) references module_info(module_id),
constraint fk_batch_id foreign key(batch_id) references batch_info(batch_id),
constraint fk_trainer_id foreign key(trainer_id) references trainer_info(trainer_id));

create table trainer_feedback(trainer_id varchar(20), question_id varchar(20), batch_id varchar(20), module_id varchar(20), trainer_rating int not null,
constraint fk1_trainer_id foreign key(trainer_id) references trainer_info(trainer_id),
constraint fk_question_id foreign key(question_id) references questions(question_id),
constraint fk1_batch_id foreign key(batch_id) references batch_info(batch_id),
constraint fk2_module_id foreign key(module_id) references module_info(module_id));

create table associate_feedback (associate_id varchar(20) not null, question_id varchar(20) not null, module_id varchar(20) not null, associate_rating int not null,
constraint fk1_associate_id foreign key(associate_id) references associate_info(associate_id),
constraint fk1_question_id foreign key(question_id) references questions(question_id),
constraint fk3_module_id foreign key (module_id) references module_info(module_id));

create table login_details (user_id varchar(20), user_password varchar(20)) ;

-- EXERCISE 3.2

create table product (product_id int primary key, product_name varchar(20), product_price int not null);

create table user_info(user_id varchar(10) primary key, product_id int,
constraint fk_product_id foreign key(product_id) references product(product_id), username varchar(30));

alter table product 
modify product_price int;

insert into product values (1,' A Dongle','290'),(2, 'B Dongle',1250);
insert into product(product_id,product_name) values (3,'C Dongle');

set foreign_key_checks = 1;
select * from user_info;
insert into user_info values
('U001',1,'Ramesh'),('U002',11,'Mahesh');
select * from user_info;

drop table user_info;