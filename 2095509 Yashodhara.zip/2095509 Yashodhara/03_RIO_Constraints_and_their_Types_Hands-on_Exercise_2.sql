create database rio_3_2;
use rio_3_2;

-- EXERCISE 3.1

create table student_info
(
registration_Number Varchar(20) PRIMARY KEY,
student_Name Varchar(30) not null,
branch Varchar(30),
contact Varchar(25),
date_of_birth Date,
date_of_joining Date,
address varchar(250),
email varchar(250)
);

create table subjects_info(
subject_Code varchar(20) PRIMARY KEY,
subject_Name Varchar(50) not null,
weightage float not null);

create table student_marks(
registration_Number Varchar(20),
subject_code varchar(20),
semester int not null,
marks int default 0,
constraint fk_registration_number foreign key (registration_number) references student_info(registration_number),
constraint fk_subject_code foreign key (subject_code) references subjects_info(subject_code));

create table student_result(
registration_Number Varchar(20),
semester int not null,
gpa float not null,
is_eligible_scholarship char(5) default 'Yes',
constraint fk_registration_number1 foreign key (registration_number) references student_info(registration_number));

-- EXERCISE 3.2

ALTER TABLE subjects_info
ADD constraint uq_Subject_Name UNIQUE (subject_name);
ALTER TABLE student_info
ADD constraint uq_contact UNIQUE (contact);
ALTER TABLE student_info
ADD constraint uq_date_of_birth Check(date_of_birth<date_of_joining);
ALTER TABLE student_marks
ADD constraint uq_marks Check(marks<=100);
ALTER TABLE student_result
ADD constraint uq_gpa Check(gpa<=10);
ALTER TABLE student_result
ADD constraint uq_is_eligible_scholarship Check(is_eligible_scholarship in ('Y','N'));