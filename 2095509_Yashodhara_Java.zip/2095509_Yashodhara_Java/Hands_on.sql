create database 2095509_java_hands_on;
use 2095509_java_hands_on;

create table Customers (customers_registerno int,room_no varchar(30),customers_email varchar(100),mobile long ,check_in_date varchar(20),check_out_date varchar(20));