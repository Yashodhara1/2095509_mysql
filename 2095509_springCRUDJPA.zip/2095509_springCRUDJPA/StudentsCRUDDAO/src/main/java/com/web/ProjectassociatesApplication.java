package com.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectassociatesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectassociatesApplication.class, args);
	}

}
